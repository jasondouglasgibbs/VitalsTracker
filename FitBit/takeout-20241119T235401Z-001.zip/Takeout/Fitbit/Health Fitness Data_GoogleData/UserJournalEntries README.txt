Journal Entries Data Export

The Journal Entries data file includes all your journal entries.

----------

User Journal Entries.csv

  entry_id             - Unique id of the journal entry
  log_time             - Date at which the entry was logged
  log_type             - The type of entry logged, for example: mood
  value                - Value selected/input for the entry
  source               - The source of the data
  platform             - The platform where the data was logged, can be 'WEB', 'MOBILE', 'DEVICE'
  reference_namespace  - The type of reference associated with the data
  reference_id         - Id of object referenced by the entry
  metadata             - Metadata that may include additional information, such as the last update time