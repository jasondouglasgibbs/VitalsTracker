The respiratory rate (or breathing rate) is the rate at which breathing occurs. This is usually measured in breaths per minute.

The "Daily Respiration Rate Summary" files include daily granularity recordings of your Respiratory Rate during a sleep. The description is as follows:

daily_respiratory_rate: Breathing rate average estimated from deep sleep when possible, and from light sleep when deep sleep data is not available.